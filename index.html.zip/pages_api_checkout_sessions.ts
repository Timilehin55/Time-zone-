import type { NextApiRequest, NextApiResponse } from 'next'
import Stripe from 'stripe'

const stripeSecret = process.env.STRIPE_SECRET_KEY || ''
const stripe = stripeSecret ? new Stripe(stripeSecret, { apiVersion: '2023-08-16' }) : null

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end()
  const { price, name } = req.body

  if (!stripe) {
    return res.status(200).json({ message: 'Stripe not configured. Set STRIPE_SECRET_KEY in env to enable.', checkoutUrl: null })
  }

  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [{ price_data: { currency: 'usd', product_data: { name }, unit_amount: price }, quantity: 1 }],
      mode: 'payment',
      success_url: `${req.headers.origin}/?success=true`,
      cancel_url: `${req.headers.origin}/?canceled=true`
    })

    res.json({ checkoutUrl: session.url })
  } catch (err: any) {
    res.status(500).json({ error: err.message })
  }
}