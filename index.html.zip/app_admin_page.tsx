'use client'

import { useEffect, useState } from 'react'

type Product = {
  id: string
  name: string
  price: number
}

export default function AdminPage() {
  const [products, setProducts] = useState<Product[]>([])
  const [name, setName] = useState('')
  const [price, setPrice] = useState('')

  useEffect(() => {
    fetch('/api/admin/products')
      .then((r) => r.json())
      .then((data) => setProducts(data))
  }, [])

  async function createProduct(e: any) {
    e.preventDefault()
    const res = await fetch('/api/admin/products', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, price: Number(price) })
    })
    const p = await res.json()
    setProducts((s) => [p, ...s])
    setName('')
    setPrice('')
  }

  return (
    <div>
      <h1 className="text-2xl font-semibold">Admin</h1>
      <p className="text-sm text-gray-600">Simple protected admin UI (you must implement auth locally)</p>

      <section className="mt-6">
        <form onSubmit={createProduct} className="flex gap-2">
          <input className="border px-2 py-1" placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} />
          <input className="border px-2 py-1" placeholder="Price (cents)" value={price} onChange={(e) => setPrice(e.target.value)} />
          <button className="bg-blue-600 text-white px-3 py-1">Create</button>
        </form>
      </section>

      <section className="mt-6">
        <h2 className="font-medium">Products</h2>
        <ul className="mt-2 space-y-2">
          {products.map((p) => (
            <li key={p.id} className="border p-2 rounded bg-white">
              <div className="flex justify-between">
                <div>
                  <div className="font-semibold">{p.name}</div>
                  <div className="text-sm text-gray-600">${(p.price / 100).toFixed(2)}</div>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </section>
    </div>
  )
}