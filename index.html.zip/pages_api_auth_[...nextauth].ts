import NextAuth from 'next-auth'
import EmailProvider from 'next-auth/providers/email'
import { PrismaAdapter } from '@next-auth/prisma-adapter'
import { prisma } from '../../../lib/prisma'

export const authOptions = {
  adapter: PrismaAdapter(prisma as any),
  providers: [
    EmailProvider({
      // This uses SMTP in production; here we show console logging for dev/demo.
      server: process.env.EMAIL_SERVER ?? undefined,
      from: process.env.EMAIL_FROM ?? 'no-reply@example.com',
      async sendVerificationRequest({ identifier: email, url, provider }) {
        // For safety we log the link in server logs. In production configure SMTP.
        // eslint-disable-next-line no-console
        console.log(`Magic link for ${email}: ${url}`)
      }
    })
  ],
  pages: {
    signIn: '/api/auth/signin'
  },
  secret: process.env.NEXTAUTH_SECRET,
  session: { strategy: 'database' }
}

export default NextAuth(authOptions as any)