export default function Header() {
  return (
    <header className="flex items-center justify-between py-4">
      <div className="text-xl font-bold">Storefront</div>
      <nav>
        <a className="mr-4 text-sm text-blue-600" href="/admin">Admin</a>
        <a className="text-sm text-blue-600" href="/api/auth/signin">Sign in</a>
      </nav>
    </header>
  )
}