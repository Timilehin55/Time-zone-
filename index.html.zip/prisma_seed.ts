import { PrismaClient } from '@prisma/client'
const prisma = new PrismaClient()

async function main() {
  console.log('Seeding...')

  // Create admin user
  await prisma.user.upsert({
    where: { email: 'admin@example.com' },
    update: {},
    create: {
      email: 'admin@example.com',
      name: 'Admin User',
      role: 'ADMIN'
    }
  })

  const products = [
    { name: 'T-shirt', variants: [{ name: 'M', price: 1999 }, { name: 'L', price: 1999 }] },
    { name: 'Hoodie', variants: [{ name: 'S', price: 3999 }] },
    { name: 'Coffee Mug', variants: [{ name: 'Standard', price: 1299 }] },
    { name: 'Sticker Pack', variants: [{ name: '5-pack', price: 499 }] },
    { name: 'Cap', variants: [{ name: 'One size', price: 2499 }] },
    { name: 'Notebook', variants: [{ name: 'A5', price: 999 }] },
    { name: 'Poster', variants: [{ name: 'A2', price: 799 }] },
    { name: 'Socks', variants: [{ name: 'Pair', price: 599 }] }
  ]

  for (const p of products) {
    await prisma.product.create({ data: { name: p.name, variants: { create: p.variants } } })
  }

  console.log('Seeding finished.')
}

main()
  .catch((e) => {
    // eslint-disable-next-line no-console
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })