import type { NextApiRequest, NextApiResponse } from 'next'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '../auth/[...nextauth]'
import { prisma } from '../../../../lib/prisma'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession(req, res, authOptions as any)
  if (!session || session.user?.email !== 'admin@example.com') {
    return res.status(401).json({ error: 'Unauthorized' })
  }

  if (req.method === 'GET') {
    const products = await prisma.product.findMany({ include: { variants: true } })
    return res.json(products)
  }

  if (req.method === 'POST') {
    const { name, price } = req.body
    const product = await prisma.product.create({
      data: {
        name,
        variants: { create: { name: 'default', price: Number(price) || 0 } }
      }
    })
    return res.status(201).json(product)
  }

  res.setHeader('Allow', ['GET', 'POST'])
  res.status(405).end(`Method ${req.method} Not Allowed`)
}