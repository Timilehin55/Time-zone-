import './globals.css'
import { ReactNode } from 'react'

export const metadata = {
  title: 'Storefront - Starter',
  description: 'E-commerce starter built with Next.js, Prisma, NextAuth and Stripe'
}

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <main className="container mx-auto px-4 py-8">{children}</main>
      </body>
    </html>
  )
}