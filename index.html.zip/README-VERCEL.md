Vercel deploy

1. Push this repository to GitHub (already public)
2. In Vercel, import the repository and set the following environment variables:
   - DATABASE_URL
   - NEXTAUTH_SECRET
   - STRIPE_SECRET_KEY
   - STRIPE_PUBLISHABLE_KEY
   - EMAIL_SERVER (if you want to use real email delivery)
3. Build command: npm run build
4. Output directory: (leave default)