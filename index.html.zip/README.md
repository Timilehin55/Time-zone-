# Storefront

E-commerce starter scaffold built with:

- Next.js (app router) + TypeScript + Tailwind CSS
- NextAuth (email magic links) with Prisma adapter
- Prisma ORM (Postgres)
- Stripe (test-mode example)
- Simple protected admin UI for product CRUD
- ESLint, Prettier, Husky (pre-commit)

This repository is a starter template — it intentionally does not include any real secrets.

Local development

1. Install dependencies

   npm install

2. Create .env file (see .env.example) and set DATABASE_URL & NEXTAUTH_SECRET.

3. Generate Prisma client and run migrations (or push)

   npx prisma generate
   npx prisma db push

4. Seed database

   npm run prisma:seed

5. Run dev server

   npm run dev

Auth

- NextAuth is configured for email magic links. In development, magic links are printed to the server console when EMAIL_SERVER is not configured.
- An admin user is created by the seed script: admin@example.com

Stripe

- Stripe example Checkout session endpoint is provided. Set STRIPE_SECRET_KEY and STRIPE_PUBLISHABLE_KEY to test keys to enable.

Deploy

- Vercel: Create a new project from this repository, set environment variables (DATABASE_URL, NEXTAUTH_SECRET, STRIPE keys, EMAIL_SERVER) in the Vercel dashboard.

CI

- A GitHub Actions workflow runs lint and build on push/PR.

License

MIT