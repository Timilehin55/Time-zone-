export default function Home() {
  return (
    <div>
      <h1 className="text-3xl font-bold">Storefront — E-commerce Starter</h1>
      <p className="mt-4 text-gray-600">Next.js app router + TypeScript + Tailwind + Prisma + NextAuth + Stripe</p>
      <div className="mt-6">
        <a href="/admin" className="text-blue-600 underline">Go to Admin</a>
      </div>
    </div>
  )
}