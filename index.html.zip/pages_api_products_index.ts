import type { NextApiRequest, NextApiResponse } from 'next'
import { prisma } from '../../../lib/prisma'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    const products = await prisma.product.findMany({ include: { variants: true } })
    return res.json(products)
  }

  // Public creation for demo purposes only — protected APIs should require auth
  if (req.method === 'POST') {
    const { name, price } = req.body
    const p = await prisma.product.create({ data: { name, variants: { create: { name: 'default', price } } } })
    return res.status(201).json(p)
  }

  res.setHeader('Allow', ['GET', 'POST'])
  res.status(405).end(`Method ${req.method} Not Allowed`)
}